/* eslint-disable */
import * as L from 'leaflet';
import {LeafletLayer} from 'deck.gl-leaflet';
import {MapView} from '@deck.gl/core';
import {HeatmapLayer} from '@deck.gl/aggregation-layers';
import {points} from './points';

const map = L.map(document.getElementById('map'), {
  center: [36, -5.4],
  zoom: 8
});
L.tileLayer(
  'http://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }
).addTo(map);

const deckLayer = new LeafletLayer({
  views: [
    new MapView({
      repeat: true
    })
  ],
  layers: [
    new HeatmapLayer({
      data: points,
      id: 'heatmp-layer',
      pickable: false,
      getPosition: d => [d[0], d[1]],
      getWeight: d => d[2],
      intensity: 1,
      threshold: 0.05,
      radiusPixels: 30
      // weightsTextureSize: 1000
    })
  ]
});
map.addLayer(deckLayer);

const featureGroup = L.featureGroup();
featureGroup.addLayer(L.marker([51.4709959, -0.4531566]));
map.addLayer(featureGroup);
